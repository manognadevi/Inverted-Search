#include "header.h"

int display_db(Hash_t *arr)
{
    for (int i = 0; i < 27; i++)
    {
        if (!arr[i].link) continue;

        printf("\nIndex %d\n", i);

        Main_node *m = arr[i].link;

        while (m)
        {
            printf("%s (%d): ", m->word, m->file_count);

            Sub_node *s = m->s_link;
            while (s)
            {
                printf("[%s:%d] ", s->file_name, s->word_count);
                s = s->s_link;
            }
            printf("\n");

            m = m->m_link;
        }
    }
    return 1;
}