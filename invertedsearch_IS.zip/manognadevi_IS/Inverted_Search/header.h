#ifndef HEADER
#define HEADER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct s_node 
{
    char file_name[50];
    int word_count;
    struct s_node* s_link;
} Sub_node;

typedef struct m_node 
{
    char word[20];
    int file_count;
    struct m_node* m_link;
    Sub_node* s_link;
} Main_node;

typedef struct file 
{
    char file_name[50];
    struct file* f_link;
} File_info;

typedef struct h_table
{
    int index;
    Main_node *link;
} Hash_t;

/* Function declarations */
int validate_arguments(int argc, char *argv[], File_info **head);
int create_DB(Hash_t * , File_info *);
int display_db(Hash_t *arr);
int search_db(Hash_t *arr, char *word);
int save_db(Hash_t *arr, char *file);
int update_db(Hash_t *arr, File_info **head);

/* Internal helpers */
int openfile(Hash_t *arr, char *filename);
int validation(Hash_t *arr, char *name, char *filename, int i);
void free_db(Hash_t *arr);

#endif