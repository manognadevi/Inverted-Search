#include "header.h"

void free_db(Hash_t *arr)
{
    for (int i = 0; i < 27; i++)
    {
        Main_node *m = arr[i].link;

        while (m)
        {
            Sub_node *s = m->s_link;

            while (s)
            {
                Sub_node *temp = s;
                s = s->s_link;
                free(temp);
            }

            Main_node *tmp = m;
            m = m->m_link;
            free(tmp);
        }
    }
}