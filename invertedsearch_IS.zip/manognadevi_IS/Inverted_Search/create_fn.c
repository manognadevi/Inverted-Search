#include "header.h"

int create_DB(Hash_t *arr, File_info *head)
{
    while (head)
    {
        if (!openfile(arr, head->file_name))
            return 0;

        head = head->f_link;
    }
    printf("Database created\n");
    return 1;
}

int openfile(Hash_t *arr, char *filename)
{
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char word[100];

    while (fscanf(fp, "%s", word) != EOF)
    {
        /* Normalize */
        for (int i = 0; word[i]; i++)
        {
            word[i] = tolower(word[i]);
            if (!isalnum(word[i]))
            {
                word[i] = '\0';
                break;
            }
        }

        if (strlen(word) == 0) continue;

        int i = word[0] - 'a';
        if (i < 0 || i > 25) i = 26;

        if (validation(arr, word, filename, i))
            continue;

        Main_node *new = malloc(sizeof(Main_node));
        strcpy(new->word, word);
        new->file_count = 1;
        new->m_link = NULL;

        Sub_node *sub = malloc(sizeof(Sub_node));
        strcpy(sub->file_name, filename);
        sub->word_count = 1;
        sub->s_link = NULL;

        new->s_link = sub;

        if (!arr[i].link)
            arr[i].link = new;
        else
        {
            Main_node *temp = arr[i].link;
            while (temp->m_link)
                temp = temp->m_link;
            temp->m_link = new;
        }
    }

    fclose(fp);
    return 1;
}

int validation(Hash_t *arr, char *name, char *filename, int i)
{
    Main_node *temp = arr[i].link;

    while (temp)
    {
        if (!strcmp(temp->word, name))
        {
            Sub_node *s = temp->s_link;

            while (s)
            {
                if (!strcmp(s->file_name, filename))
                {
                    s->word_count++;
                    return 1;
                }
                s = s->s_link;
            }

            temp->file_count++;

            Sub_node *new = malloc(sizeof(Sub_node));
            strcpy(new->file_name, filename);
            new->word_count = 1;
            new->s_link = temp->s_link;
            temp->s_link = new;

            return 1;
        }
        temp = temp->m_link;
    }
    return 0;
}