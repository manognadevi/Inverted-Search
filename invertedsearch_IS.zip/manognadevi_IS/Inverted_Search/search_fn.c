#include "header.h"

int search_db(Hash_t *arr, char *word)
{
    for (int i = 0; word[i]; i++)
        word[i] = tolower(word[i]);

    int idx = word[0] - 'a';
    if (idx < 0 || idx > 25) idx = 26;

    Main_node *temp = arr[idx].link;

    while (temp)
    {
        if (!strcmp(temp->word, word))
        {
            printf("Found in %d files\n", temp->file_count);

            Sub_node *s = temp->s_link;
            while (s)
            {
                printf("%s : %d\n", s->file_name, s->word_count);
                s = s->s_link;
            }
            return 1;
        }
        temp = temp->m_link;
    }
    return 0;
}