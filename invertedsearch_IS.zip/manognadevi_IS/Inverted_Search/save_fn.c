#include "header.h"

int save_db(Hash_t *arr, char *file)
{
    FILE *fp = fopen(file, "w");
    if (!fp) return 0;

    for (int i = 0; i < 27; i++)
    {
        if (!arr[i].link) continue;

        fprintf(fp, "#%d;", i);

        Main_node *m = arr[i].link;

        while (m)
        {
            fprintf(fp, "%s;%d;", m->word, m->file_count);

            Sub_node *s = m->s_link;
            while (s)
            {
                fprintf(fp, "%s;%d;", s->file_name, s->word_count);
                s = s->s_link;
            }
            m = m->m_link;
        }
        fprintf(fp, "#\n");
    }

    fclose(fp);
    printf("Saved\n");
    return 1;
}