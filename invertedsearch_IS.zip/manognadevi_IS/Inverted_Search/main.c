#include "header.h"

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("ERROR: Provide input files\n");
        return 0;
    }

    File_info *head = NULL;

    if (validate_arguments(argc, argv, &head) == 0)
    {
        printf("No valid files\n");
        return 0;
    }

    Hash_t arr[27];
    for (int i = 0; i < 27; i++)
    {
        arr[i].index = i;
        arr[i].link = NULL;
    }

    int choice, created = 0, updated = 0;

    while (1)
    {
        printf("\n1.Create\n2.Display\n3.Update\n4.Search\n5.Save\n6.Exit\n");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                if (!created)
                {
                    create_DB(arr, head);
                    created = 1;
                }
                else
                    printf("Already created\n");
                break;

            case 2:
                display_db(arr);
                break;

            case 3:
                if (!created && !updated)
                {
                    update_db(arr, &head);
                    updated = 1;
                }
                else
                    printf("Cannot update after create\n");
                break;

            case 4:
            {
                char word[100];
                printf("Enter word: ");
                scanf("%s", word);

                if (!search_db(arr, word))
                    printf("Word not found\n");
                break;
            }

            case 5:
            {
                char file[100];
                printf("Enter filename: ");
                scanf("%s", file);
                save_db(arr, file);
                break;
            }

            case 6:
                free_db(arr);
                exit(0);
        }
    }
}