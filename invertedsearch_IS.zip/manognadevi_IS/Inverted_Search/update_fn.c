#include "header.h"

int update_db(Hash_t *arr, File_info **head)
{
    char file[100];
    printf("Enter backup file: ");
    scanf("%s", file);

    FILE *fp = fopen(file, "r");
    if (!fp) return 0;

    int index;

    while (fscanf(fp, "#%d;", &index) == 1)
    {
        while (1)
        {
            char word[20];
            int fcount;

            if (fscanf(fp, "%[^;];%d;", word, &fcount) != 2)
                break;

            Main_node *m = malloc(sizeof(Main_node));
            strcpy(m->word, word);
            m->file_count = fcount;
            m->m_link = arr[index].link;
            arr[index].link = m;

            Sub_node *tail = NULL;

            for (int i = 0; i < fcount; i++)
            {
                char fname[50];
                int wcount;

                fscanf(fp, "%[^;];%d;", fname, &wcount);

                Sub_node *s = malloc(sizeof(Sub_node));
                strcpy(s->file_name, fname);
                s->word_count = wcount;
                s->s_link = NULL;

                if (!m->s_link)
                    m->s_link = tail = s;
                else
                {
                    tail->s_link = s;
                    tail = s;
                }
            }

            int c = fgetc(fp);
            if (c == '#' || c == EOF)
                break;
            ungetc(c, fp);
        }
    }

    fclose(fp);
    printf("Updated\n");
    return 1;
}