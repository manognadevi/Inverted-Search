# Inverted_Search
An inverted index maps words/numbers to their locations in files or documents, enabling fast full-text search. Widely used in document retrieval systems and search engines, it improves search speed at the cost of extra processing when adding data. This project implements inverted search using Hash Algorithms.
